﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Webhook_WebAPI.Models;

namespace Webhook_WebAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WebhookController : ControllerBase
    {
        [HttpPost]
        public IActionResult Receive([FromBody] dynamic data)

        {
            Console.WriteLine("Webhook received:" + data);
            return Ok();
        }
    }
}