﻿using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Newtonsoft.Json;
using System.Text.Json.Serialization;
namespace Webhook_WebAPI
{
    public class WebhookSender
    {
        private static readonly HttpClient client = new HttpClient();

        public async Task SendWebhookAsync(object eventData)
        {
            var jsonContent = JsonConverter.SerialiazeObject(eventData);
            var content = new StringContent(jsonContent, Encoding.UTF8, "application/json");
            var response = await client.PostAsync("https://your-client-url/webhook", content);
            if (response.IsSuccessStatusCode)
            {
                Console.WriteLine("Webhook sent successfully.");
            }
            else
            {
                Console.WriteLine("Failed to send webhook. Status code :  + response.StatusCode");
            }
        }
    }
}
  