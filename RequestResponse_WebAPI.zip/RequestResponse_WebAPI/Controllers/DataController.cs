﻿using Microsoft.AspNetCore.Mvc;

namespace RequestResponse_WebAPI.Controllers
{
    public class DataController : ControllerBase
    {
        public IActionResult Get()
        {
            var data = new
            {
                Id = 1,
                Message = "Hello from the server!"
            };
            return Ok(data);
        }
    }
}
