﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
namespace RequestResponse_WebAPI.Controllers
{
    public class RequestData
    {
        static readonly HttpClient client = new HttpClient();
        static async Task Main()
        {
            var response = await client.GetAsync("https://localhost:5001/data");
            if (response.IsSuccessStatusCode)
            {
                var responseData = await response.Content.ReadAsStringAsync();
                Console.WriteLine("Received data: " + responseData);
            }
            else
            {
                Console.WriteLine($"Request failed with ststus code: {response.StatusCode}");
            }
        }
    }
}




